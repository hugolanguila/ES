#ifndef PROC_H
#define PROC_H

void ordenar( int *datos );
int promedio( int *datos );
int n_pares( int *datos );
int n_primos( int *datos );
int es_primo( int x );
#endif
