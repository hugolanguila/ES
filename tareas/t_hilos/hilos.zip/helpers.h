#ifndef HELP_C
#define HELP_C

int *reservar_memoria();
void generar_datos( int *datos );
void imprimir_datos( int *datos );


#endif
