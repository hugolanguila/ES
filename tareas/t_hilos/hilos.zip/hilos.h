#ifndef HILOS_H
#define HILOS_H

void *fun_hilo( void *arg );

#endif
