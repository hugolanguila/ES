#ifndef DEFS_H
#define DEFS_H

#define NH 4
#define NDATOS 128
#define TOPE 256
#endif
